JMDB (c) Uwe Freese, Juergen Ulbts
http://www.jmdb.de/


These are example movie collections.
They appear in the menu "Movie Collections" of the JMDB main window.

A collection is displayed as a table and consists of a set of movies.
There have to be 2 files for each collection, one definition file (.def)
and a data file (.data). All other files in this directory are ignored.

In the easiest case, the data file is a simple CSV file, that means some
strings separated by ;

You can find a simple example in "movies last seen in cinema_Example.def",
more examples and options in "Videotapes_Example.def" or in the 
"Movies_JohnDoe_Example_MySQL.def" where the data can be exported from
the "Movies_JohnDoe_Example_MySQL.ods" (OpenOffice -- 'Save As..' *.CSV)
or the "Movies_JohnDoe_Example_MySQL.xls" (Microsoft Excel) sheet.