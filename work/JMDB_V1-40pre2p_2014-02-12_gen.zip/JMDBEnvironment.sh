#!/bin/sh

# The path of the JMDB installation (normally the current directory
# which is accessed using the '%CD%' variable).
# In this normal case you can leave it as it is.
# Used Linux shell help from this entry:
# http://stackoverflow.com/questions/59895/can-a-bash-script-tell-what-directory-its-stored-in
JMDB_INST_PATH=$(cd "$(dirname '${BASH_SOURCE[0]}')" && pwd )
echo "Current directory: ${JMDB_INST_PATH}"

# The name of the database service to start before JMDB will be started
# when the autoupdater is started.
# Leave it blank/empty if nothing should be done.
#
# Note:
# =====
# Windows: You'll have to run the command line with extended ADMIN rights
#          otherwise there will be an error message (Windows Vista, Win7, etc.).
#          Uses: net start <DATABASE_SERVICE_NAME>
# Linux..: Your account needs to have the right to start and stop services.
#          Uses: service <DATABASE_SERVICE_NAME> start
#
DATABASE_SERVICE_NAME=

# The FTP-Server address including the path on the server (remote).
# Choose one of the servers below by removing the comment.
# By default the German FU-Berlin (Free University Berlin) is active.
#
# The current list of available servers can be found here:
# http://www.imdb.com/interfaces
IMDB_FTP_ADDRESS="ftp://ftp.fu-berlin.de/pub/misc/movies/database"
# IMDB_FTP_ADDRESS="ftp://ftp.funet.fi/pub/mirrors/ftp.imdb.com/pub"
# IMDB_FTP_ADDRESS="ftp://ftp.sunet.se/pub/tv+movies/imdb"

# Space separated list of the IMDb list files that have to be downloaded.
#
# Important:
# ==========
# All IMDb files you have selected in the JMDB setup dialog must be listed
# here, otherwise JMDB complains about missing files or skips them.
declare -a IMDB_DATA_FILE_LIST
IMDB_COMPLETE_DATA_FILE_LIST=('actors.list.gz' 'actresses.list.gz' 'aka-names.list.gz' 'aka-titles.list.gz' 'alternate-versions.list.gz' 'biographies.list.gz' 'business.list.gz' 'certificates.list.gz' 'cinematographers.list.gz' 'color-info.list.gz' 'composers.list.gz' 'costume-designers.list.gz' 'countries.list.gz' 'crazy-credits.list.gz' 'directors.list.gz' 'distributors.list.gz' 'editors.list.gz' 'genres.list.gz' 'german-aka-titles.list.gz' 'goofs.list.gz' 'italian-aka-titles.list.gz' 'keywords.list.gz' 'language.list.gz' 'literature.list.gz' 'locations.list.gz' 'miscellaneous-companies.list.gz' 'miscellaneous.list.gz' 'movie-links.list.gz' 'movies.list.gz' 'mpaa-ratings-reasons.list.gz' 'plot.list.gz' 'producers.list.gz' 'production-companies.list.gz' 'production-designers.list.gz' 'quotes.list.gz' 'ratings.list.gz' 'release-dates.list.gz' 'running-times.list.gz' 'sound-mix.list.gz' 'soundtracks.list.gz' 'special-effects-companies.list.gz' 'taglines.list.gz' 'technical.list.gz' 'trivia.list.gz' 'writers.list.gz')
JMDB_UNSUPPORTED_DATA_FILE_LIST=('miscellaneous-companies.list.gz' 'special-effects-companies.list.gz')

# The base folder where an additional subdirectory (.\YYYY-MM-DD) is
# created each week for the IMDb data.
IMDB_DATA_BASE_DIR=/usr/src/IMDb

# ===================================================================
# OPTIONAL: The base folder where the IMDb IDs files are located.
#           Normally this is a sub-directory of ${IMDB_DATA_BASE_DIR}
#           These files are not available to the public and not
#           available from the IMDb (except maybe if you have a
#           license).
IMDB_ID_BASE_DIR=${IMDB_DATA_BASE_DIR}/IMDb_IDs

# The path to the directory where the INFO-ZIP UNZIP.EXE can be found.
# This is only needed if you have access to the IMDB MOVIE ID file.
# You can download ZIP.EXE/UNZIP.EXE for Windows here:
# ftp://ftp.info-zip.org/pub/infozip/win32/
INFOZIP_INST_PATH=/usr/bin
# ===================================================================
