#!/bin/bash
IMDB_IMPORT_PATH=$1
if [ "x${IMDB_IMPORT_PATH}" == "x" ]; then
   # No parameter
   java -Xmx850M -classpath .:jmdb.jar:postgresql-8.4-701.jdbc3.jar:mysql-connector-java-5.1.11-bin.jar:./plugins/export/itext-1.4.3.jar jmdb.base.JMDBMain debugmode=10
else
   # Start with parameter (IMDB_IMPORT_PATH) 
   echo "Using IMDb import path ${IMDB_IMPORT_PATH}"
   java -Xmx850M -classpath .:jmdb.jar:postgresql-8.4-701.jdbc3.jar:mysql-connector-java-5.1.11-bin.jar:./plugins/export/itext-1.4.3.jar jmdb.base.JMDBMain debugmode=10 importpath="${IMDB_IMPORT_PATH}" importwithindex
fi
