#!/bin/bash
clear


# ================================
#          PAUSE FUNCTION
# ================================
function PAUSE {
   read -p "Press [Enter] key to continue..."
}


# ================================
#    INIT OF VARIABLES FUNCTION
# ================================
function INITVARS() {
    echo "Init variables..."
    source ./JMDBEnvironment.sh

    # Initialisation of a helper variable to check if the data is
    # complete (the value is modified and checked later..after
    # the download step is complete).
    IMDB_DATA_COMPLETE=0

    # A file to write the error messages to.
    GLOBAL_ERROR_FILE=${JMDB_INST_PATH}/startlinuxautoupdater_ERROR.log

    # Set IMDb file date to fetch (will be automatically set later).
    IMDB_FETCH_DATE=
}


# ================================
#          MAIN FUNCTION
# ================================
function MAIN() {
    # Initialise additional variables based on JMDBEnvironment.sh
    INITVARS

    # Check if the IMDb base directory exists.
    # Create it if required.
    if [ ! -d "${IMDB_DATA_BASE_DIR}/" ]; then
        mkdir -p "${IMDB_DATA_BASE_DIR}/"
    fi

    # Get and check the date of the current movies.list.gz file
    # on the FTP-Server.
    echo "Checking movies.list.gz on FTP-Server..."
    curl -v -X "NLST movies.list.gz" -Q "-MDTM movies.list.gz" "${IMDB_FTP_ADDRESS}/" 2>"${IMDB_DATA_BASE_DIR}/ftp_directory_listing.lst"

    #
    # Search for the date in the ftp_directory_listing.lst file (Pattern: "^\ 213\ [0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]" )
    # ===========================
    #   > MDTM movies.list.gz
    #   < 213 20121109132726
    # ===========================
    echo "Checking content of '${IMDB_DATA_BASE_DIR}/ftp_directory_listing.lst' for the date..."
    TEMP_IMDB_FETCH_DATE=$(grep -o -P "< 213 \d{8}" "${IMDB_DATA_BASE_DIR}/ftp_directory_listing.lst")

    #
    # Check the fetched result.
    #
    if [ "${TEMP_IMDB_FETCH_DATE:0:6}" == "< 213 " ]; then
        # Convert the line with the date as fetched
        # into an ISO-8601 date format.
        IMDB_FETCH_DATE=${TEMP_IMDB_FETCH_DATE:6:4}-${TEMP_IMDB_FETCH_DATE:10:2}-${TEMP_IMDB_FETCH_DATE:12:2}
        echo "IMDB_FETCH_DATE is set to... ${IMDB_FETCH_DATE}"
    else
       exit -99
    fi

    echo "Calling IMDB_DATA_DOWNLOADER() function..."
    IMDB_DATA_DOWNLOADER

    echo "Calling IMDB_ID_EXTRACT() function..."
    IMDB_ID_EXTRACT

    #
    # Go through the list of given IMDb files and check if
    # they have been downloaded.
    #
    for IMDB_DATA_FILE in "${IMDB_DATA_FILE_LIST[@]}"
    do
        if [ ! -f "${IMDB_DATA_BASE_DIR}/${IMDB_FETCH_DATE}/${IMDB_DATA_FILE}" ]; then
            IMDB_DATA_COMPLETE=$(expr ${IMDB_DATA_COMPLETE} - 1)
        fi
    done

    #
    # If IMDB_DATA_COMPLETE == 0 then all files are there and we
    # can call the [optional] service and finally run JMDB...
    #
    if [ ${IMDB_DATA_COMPLETE} -eq 0 ]; then
        # ==================================================
        # Start the database service using the given name...
        # ==================================================
        if [ ! "x${DATABASE_SERVICE_NAME}" == "x" ]; then
            service ${DATABASE_SERVICE_NAME} start
        fi

        # =============
        # Start JMDB...
        # =============
        echo "Starting normal JMDB startup script with necessary parameters..."
        ./startlinux.sh ${IMDB_DATA_BASE_DIR}/${IMDB_FETCH_DATE}
    else
        echo "Files are incomplete...exiting now..."
        echo
        exit ${IMDB_DATA_COMPLETE}
    fi

    #
    # Call exit function
    #
    ENDSCRIPT
}


# ================================
# Download IMDb list files via FTP
# ================================
function IMDB_DATA_DOWNLOADER() {
    # ===================================================
    # Check the JMDB.cfg files for deselected list files.
    # ===================================================
    JMDB_CFG_IMDB_FILES

    # Append the files unsupported by JMDB.
    JMDB_SKIP_FILE_LIST=("${JMDB_SKIP_FILE_LIST[@]}" "${JMDB_UNSUPPORTED_DATA_FILE_LIST[@]}")

    # Initialize parameter to check if the files can be skipped
    # or not.
    FOUND_JMDB_SKIP_FILE=0

    # ==============================================
    # Loop to generate the list of files to download
    # by checking different file lists.
    # ==============================================
    for IMDB_COMPLETE_DATA_FILE in "${IMDB_COMPLETE_DATA_FILE_LIST[@]}"
    do
        FOUND_JMDB_SKIP_FILE=0

        # ====================================
        # Inner look checking which files have
        # to be skipped.
        # ====================================
        for JMDB_SKIP_FILE in "${JMDB_SKIP_FILE_LIST[@]}"
        do
            if [ "${IMDB_COMPLETE_DATA_FILE}" == "${JMDB_SKIP_FILE}" ]; then
                FOUND_JMDB_SKIP_FILE=1
            fi
        done

        # =====================================================
        # Add file to download list if FOUND_JMDB_SKIP_FILE==0.
        # =====================================================
        if [[ ${FOUND_JMDB_SKIP_FILE} -eq 0 ]]; then
            IMDB_DATA_FILE_LIST=("${IMDB_DATA_FILE_LIST[@]}" "${IMDB_COMPLETE_DATA_FILE}")
        fi
    done

    echo "About to download these files: ${IMDB_DATA_FILE_LIST[@]}"

    # Check if the IMDb base directory including the subdirectory with the release date
    # for the current movies.list.gz file exists.
    # Create it if required.
    if [ ! -d "${IMDB_DATA_BASE_DIR}/${IMDB_FETCH_DATE}/" ]; then
        mkdir -p "${IMDB_DATA_BASE_DIR}/${IMDB_FETCH_DATE}/"
    fi

    # Go through the list of given IMDb files and download each of
    # them (the downloader tries it multiple times if required).
    for IMDB_DATA_FILE in "${IMDB_DATA_FILE_LIST[@]}"
    do
        echo "Downloading ${IMDB_DATA_FILE}..."
        #wget --continue --tries=5 --wait=5 --timestamping --directory-prefix="${IMDB_DATA_BASE_DIR}/${IMDB_FETCH_DATE}/${IMDB_DATA_FILE}" "${IMDB_FTP_ADDRESS}/${IMDB_DATA_FILE}"
        curl -C - --retry 5 --retry-delay 5 --progress-bar --remote-time --output "${IMDB_DATA_BASE_DIR}/${IMDB_FETCH_DATE}/${IMDB_DATA_FILE}" "${IMDB_FTP_ADDRESS}/${IMDB_DATA_FILE}"
        echo
        echo
    done

    # echo "IMDB_DATA_COMPLETE status after downloading files: ${IMDB_DATA_COMPLETE}"
}


# ================================
#       Extract IMDb ID file
# ================================
function IMDB_ID_EXTRACT() {
    if [ -d "${IMDB_ID_BASE_DIR}/" ]; then
#        while read IMDB_ID_FILE
#        do
#            if [ ! -f "${IMDB_DATA_BASE_DIR}/${IMDB_FETCH_DATE}/movies_imdbid.list" ]; then
#                echo "Found '${IMDB_ID_FILE}' ...extracting..."
#                unzip -n "${IMDB_ID_FILE}" -d "${IMDB_DATA_BASE_DIR}/${IMDB_FETCH_DATE}"
#            else
#                break;
#            fi
#        done <<< "`ls -t -1 ${IMDB_ID_BASE_DIR}/movies_imdbid_????-??-??.zip`"

#        Other option...without using the ls command call.
        IMDB_ID_FILE_LIST=(${IMDB_ID_BASE_DIR}/movies_imdbid_????-??-??.zip)
        for ((i=${#IMDB_ID_FILE_LIST[@]}-1; i>=0; i--))
        do
            if [ ! -f "${IMDB_DATA_BASE_DIR}/${IMDB_FETCH_DATE}/movies_imdbid.list" ]; then
                echo "Found '${IMDB_ID_FILE_LIST[$i]}' ...extracting..."
                unzip -n "${IMDB_ID_FILE_LIST[$i]}" -d "${IMDB_DATA_BASE_DIR}/${IMDB_FETCH_DATE}"
            else
                break;
            fi
        done

        echo
    fi
}


function JMDB_CFG_IMDB_FILES() {
    # Save default field separator.
    local oIFS=${IFS}
    # Set new field separator.
    local IFS=';'

    #
    # Get the line containing the IMDb files to skip from the
    # JMDB configuration file (jmdb.cfg).
    #
    TEMP_JMDB_SKIP_FILE_LIST=$(grep -F "JMDBMain.cfgDeselectedImportFiles=" "${JMDB_INST_PATH}/jmdb.cfg")

    #
    # Remove the 'JMDBMain.cfgDeselectedImportFiles=' from the string
    # and copy the string elements into the array.
    #
    JMDB_SKIP_FILE_LIST=(${TEMP_JMDB_SKIP_FILE_LIST:34})

    # Remove last element from the array (contains '\r').
    unset JMDB_SKIP_FILE_LIST[${#JMDB_SKIP_FILE_LIST[@]}-1]

    # Reset default field separator (set it to the original value).
    local IFS=${oIFS}

    #
    # Append the file extension for the IMDb list files (.list.gz)
    # to each entry of the array.
    #
    local IMDB_LIST_FILE_EXTENSION=.list.gz
    local ArrayItemCounter=${#JMDB_SKIP_FILE_LIST[@]}
    for ((i=0; i < ${ArrayItemCounter}; i++))
    do
       JMDB_SKIP_FILE_LIST[i]=${JMDB_SKIP_FILE_LIST[i]}${IMDB_LIST_FILE_EXTENSION}
    done
}


# ================================
#          Exit function
# ================================
function ENDSCRIPT() {
    echo
    echo ==========
    echo The End...
    echo ==========
    echo
    exit 0
}

# Start main script code...
MAIN
